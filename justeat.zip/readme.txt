This design to help devloppers to understand how to make simple web - forms 

Only css , html and some javascript is used .

Pages can be edited in order to Cover dependencies .


This is a simple project TO DO :


1 - Integrate sql commands or api in order to save registring data forms

2 - Most browser has auto translating enabled . integrate- Dictionnary Api , might be possible in some cases and for better auto language support

3 - Share and do not forget credit ~~~